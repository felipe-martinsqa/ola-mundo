/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mapa1;

import javax.swing.JOptionPane;

/**
 *
 * @author Oruc
 */
public class Locacao {
    
    private int tempoMinuto;
    private char necessitaEquipamento;
    private Locatario locatario;
    private Quadra quadra;

    public double calcularLocacao() {
    double valorTotal = quadra.getValorPorMinuto() * tempoMinuto;
    
    if (tempoMinuto > 120) {
        valorTotal *= 0.9; 
    }
    
    if (necessitaEquipamento == 'S') {
        valorTotal += 50; 
    }
    
    return valorTotal;
}
    public void mostrarResumoLocacao() {
    String message = "Locação realizada com sucesso!\n\n";
    message += "Locatário:\n";
    message += "Nome: " + locatario.getNome() + "\n";
    message += "CPF: " + locatario.getCpf() + "\n";
    message += "Ano de nascimento: " + locatario.getAnoNascimento() + "\n";
    message += "Telefone: " + locatario.getTelefone() + "\n\n";
    message += "Quadra:\n";
    message += "Nome: " + quadra.getNome() + "\n";
    message += "Tipo: " + quadra.getTipo() + "\n";
    message += "Valor por minuto: R$" + quadra.getValorPorMinuto() + "\n\n";
    message += "Locação:\n";
    message += "Tempo em minutos: " + tempoMinuto + "\n";
    message += "Necessita de equipamento: " + (necessitaEquipamento == 'S' ? "Sim" : "Não") + "\n";
    message += "Valor total da locação: R$" + calcularLocacao()+ "\n";
    JOptionPane.showMessageDialog(null, message);
}
    
    public void cadastrarLocacao(){
        quadra.cadastrarQuadra();
        locatario.cadastrarLocatario();
        if (!locatario.verificarMaiorIdade()){
         JOptionPane.showMessageDialog(null, "O locatário é menor de idade");
         System.exit(0);
        }
        this.tempoMinuto = Integer.parseInt(JOptionPane.showInputDialog("Qual o tempo em minutos para locação?"));
        this.necessitaEquipamento = JOptionPane.showInputDialog("É necessário equipamento? (S/N)").toUpperCase().charAt(0);
        mostrarResumoLocacao();
    }
    
    public Locacao(){
        this.locatario = new Locatario();
        this.quadra = new Quadra();
    }
    public Locacao(int tempoMinuto, char necessitaEquipamento, Locatario locatario, Quadra quadra) {
        this.tempoMinuto = tempoMinuto;
        this.necessitaEquipamento = necessitaEquipamento;
        this.locatario = locatario;
        this.quadra = quadra;
    }

    public int getTempoMinuto() {
        return tempoMinuto;
    }

    public void setTempoMinuto(int tempoMinuto) {
        this.tempoMinuto = tempoMinuto;
    }

    public char getNecessitaEquipamento() {
        return necessitaEquipamento;
    }

    public void setNecessitaEquipamento(char necessitaEquipamento) {
        this.necessitaEquipamento = necessitaEquipamento;
    }

    public Locatario getLocatario() {
        return locatario;
    }

    public void setLocatario(Locatario locatario) {
        this.locatario = locatario;
    }

    public Quadra getQuadra() {
        return quadra;
    }

    public void setQuadra(Quadra quadra) {
        this.quadra = quadra;
    }
}
