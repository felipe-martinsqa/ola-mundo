/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mapa1;

import java.util.Calendar;
import javax.swing.JOptionPane;

/**
 *
 * @author Oruc
 */
public class Locatario {
    
    private String nome, cpf, telefone;
    private int anoNascimento;

    public Locatario(){
        
    }
    public Locatario(String nome, String cpf, String telefone, int anoNascimento) {
        this.nome = nome;
        this.cpf = cpf;
        this.telefone = telefone;
        this.anoNascimento = anoNascimento;
    }

    public boolean verificarMaiorIdade(){
        int anoAtual = Calendar.getInstance().get(Calendar.YEAR);
        
        if ((anoAtual - anoNascimento) >= 18){
            return true;
        }else{
            return false;
        }
        
    }
    
    public void cadastrarLocatario(){
        this.nome = JOptionPane.showInputDialog("Qual o nome do locatário?");
        this.cpf = JOptionPane.showInputDialog("Qual o CPF do locatário?");
        this.telefone = JOptionPane.showInputDialog("Qual o telefone do locatário?");
        this.anoNascimento = Integer.parseInt(JOptionPane.showInputDialog("Qual o ano de nascimento?"));
    }
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public int getAnoNascimento() {
        return anoNascimento;
    }

    public void setAnoNascimento(int anoNascimento) {
        this.anoNascimento = anoNascimento;
    }
}
