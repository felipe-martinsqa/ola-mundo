/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mapa1;

import javax.swing.JOptionPane;

/**
 *
 * @author Oruc
 */
public class Quadra {
    private String nome, tipo;
    private int valorPorMinuto;

    public void cadastrarQuadra(){
        this.nome = JOptionPane.showInputDialog("Qual o nome da quadra?");
        this.tipo = JOptionPane.showInputDialog("Qual o tipo da quadra?");
        this.valorPorMinuto = Integer.parseInt(JOptionPane.showInputDialog("Informe o valor por minuto da quadra:"));
    }
    
    public Quadra (){
        
    }
    public Quadra(String nome, String tipo, int valorPorMinuto) {
        this.nome = nome;
        this.tipo = tipo;
        this.valorPorMinuto = valorPorMinuto;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getValorPorMinuto() {
        return valorPorMinuto;
    }

    public void setValorPorMinuto(int valorPorMinuto) {
        this.valorPorMinuto = valorPorMinuto;
    }
}
